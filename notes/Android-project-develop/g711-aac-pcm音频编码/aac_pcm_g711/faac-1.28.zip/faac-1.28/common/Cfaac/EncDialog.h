extern BOOL DialogMsgProcAbout(HWND hWndDlg, UINT Message, WPARAM wParam, LPARAM lParam);
extern BOOL CALLBACK DIALOGMsgProcEnc(HWND hWndDlg, UINT Message, WPARAM wParam, LPARAM lParam);
