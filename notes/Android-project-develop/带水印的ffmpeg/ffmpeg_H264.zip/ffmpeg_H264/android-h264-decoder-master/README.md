Android H264 video decoding class, using JNI as an interface to the FFmpeg libraries.

Compile with:

    <Android NDK path>/ndk-build

H264Decoder is a Java class that calls into the C functions in jni/h264decoder.c
